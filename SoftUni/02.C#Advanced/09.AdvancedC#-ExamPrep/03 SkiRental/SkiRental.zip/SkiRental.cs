﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SkiRental
{
    internal class SkiRental
    {
        private string name;
        private int capacity;
        private List<Ski> data;

        public SkiRental(string name, int capacity)
        {
            this.name = name;
            this.capacity = capacity;
            this.data = new List<Ski>();
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        
        public int Capacity
        {
            get { return capacity; }
            set { capacity = value; }
        }

        public int Count { get { return this.data.Count; } }

        public void Add(Ski ski)
        {
            if (capacity > this.Count)
            {
                data.Add(ski);
            }
        }
        public bool Remove(string manufacturer, string model)
        {
            Ski ski = data.FirstOrDefault(x => x.Manufacturer == manufacturer && x.Model == model);
            if (ski == default)
            {
                return false;
            }

            data.Remove(ski);
            return true;
        }

        public Ski GetSki(string manufacturer, string model) => data.FirstOrDefault(x => x.Manufacturer == manufacturer && x.Model == model);

        public Ski GetNewestSki() => data.OrderByDescending(x => x.Year).FirstOrDefault();
        public string GetStatistics()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"The skis stored in {this.Name}");

            foreach (var item in this.data)
            {
                sb.AppendLine(item.ToString());
            }

            return sb.ToString().TrimEnd();
        }
    }
}
