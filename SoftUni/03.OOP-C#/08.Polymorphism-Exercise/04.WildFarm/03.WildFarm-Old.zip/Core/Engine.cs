﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
    public class Engine
    {
        public void Run()
        {
            string input = string.Empty;
            List<Animal> animals = new List<Animal>();

            while ((input = Console.ReadLine()) != "End")
            {
                string[] animalInfo = input
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries);
                string type = animalInfo[0];
                string name = animalInfo[1];
                double weight = double.Parse(animalInfo[2]);
                string uniqueProp = animalInfo[3];

                Animal animal = null;

                if (animalInfo.Length == 5)
                {
                    
                    string breed = animalInfo[4];

                    if (type == "Cat")
                    {
                        animal = new Cat(name, weight, uniqueProp, breed);
                    }
                    else
                    {
                        animal = new Tiger(name, weight, uniqueProp, breed);
                    }
                }
                else if (type == "Owl")
                {
                    animal = new Owl (name, weight, double.Parse(uniqueProp));
                }
                else if (type == "Hen")
                {
                    animal = new Hen (name, weight, double.Parse(uniqueProp));
                }
                else if (type == "Dog")
                {
                    animal = new Dog (name, weight, uniqueProp);

                }
                else if (type == "Mouse")
                {
                    animal = new Mouse (name, weight, uniqueProp);
                }


                string[] foodInfo = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries);
                string food = foodInfo[0];
                int quantity = int.Parse(foodInfo[1]);

                animals.Add(animal);

                animal.ProduceSound(type);
                try
                {
                    animal.FeedAnimal(type, food, quantity);

                }
                catch (Exception ex)
                {

                    Console.WriteLine($"{ex.Message}");
                }
            }

            foreach (var animal in animals)
            {
                Console.WriteLine(animal);
            }

        }
    }
}
