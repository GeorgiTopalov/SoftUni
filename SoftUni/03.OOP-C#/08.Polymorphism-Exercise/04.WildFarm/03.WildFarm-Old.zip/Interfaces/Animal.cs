﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
    public abstract class Animal : IFeedable
    {
        protected Animal(string name, double weight)
        {
            Name = name;
            Weight = weight;
            FoodEaten = 0;
        }

        public string Name { get; set; }
        public double Weight { get; set; }
        public int FoodEaten { get; set; }

        public void FeedAnimal(string type, string food, int foodQuantity)
        {

            if (type == "Hen")
            {
                this.Weight += foodQuantity * 0.35;
            }
            else if (type == "Owl")
            {
                if (food != "Meat")
                {
                    throw new ArgumentException($"{type} does not eat {food}!");
                }
                this.Weight += foodQuantity * 0.25;

            }
            else if (type == "Mouse")
            {
                if (food != "Fruit" && food != "Vegetable")
                {
                    throw new ArgumentException($"{type} does not eat {food}!");
                }
                this.Weight += foodQuantity * 0.10;

            }
            else if (type == "Cat")
            {
                if (food != "Meat" && food != "Vegetable")
                {
                    throw new ArgumentException($"{type} does not eat {food}!");
                }
                this.Weight += foodQuantity * 0.30;

            }
            else if (type == "Dog")
            {
                if (food != "Meat")
                {
                    throw new ArgumentException($"{type} does not eat {food}!");
                }
                this.Weight += foodQuantity * 0.40;

            }
            else if (type == "Tiger")
            {
                if (food != "Meat")
                {
                    throw new ArgumentException($"{type} does not eat {food}!");
                }
                this.Weight += foodQuantity * 1.00;

            }
            this.FoodEaten += foodQuantity;

        }

        public void ProduceSound(string type)
        {
           if (type == "Owl")
            {
                Console.WriteLine("Hoot Hoot");
            }
           else if (type == "Hen")
            {
                Console.WriteLine("Cluck");
            }
            else if (type == "Mouse")
            {
                Console.WriteLine("Squeak");
            }
            else if (type == "Dog")
            {
                Console.WriteLine("Woof!");
            }
            else if (type == "Cat")
            {
                Console.WriteLine("Meow");
            }
            else if (type == "Tiger")
            {
                Console.WriteLine("ROAR!!!");
            }
        }
        
       
    }
}
