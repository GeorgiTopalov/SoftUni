﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage
{
    public interface IHuman
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
