﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace ValidationAttributes
{
    public class Validator
    {
        public static bool isValid(object person)
        {
            PropertyInfo[] propertyInfos = person
                .GetType()
                .GetProperties()
                .Where(x => x.GetCustomAttributes(typeof(MyValidationAttribute)).Any()).ToArray();

            foreach (PropertyInfo propertyInfo in propertyInfos)
            {
                var value = propertyInfo.GetValue(person);
                MyValidationAttribute attribute = propertyInfo.GetCustomAttribute<MyValidationAttribute>();

            bool isValid = attribute.isValid(value);

                if (!isValid)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
