import page from '../node_modules/page/page.mjs';
import { decorateContext, renderNav } from './midlewares/decorateCtx.js';
import { createView } from './views/createView.js';
import { detailsView } from './views/detailsView.js';
import { editView } from './views/editView.js';
import { homeView } from './views/homeView.js';
import { loginView } from './views/loginView.js';
import { profileView } from './views/profileView.js';
import { registerView } from './views/registerView.js';
import { authMiddleware } from './midlewares/authentication.js';
//import { decorateContext } from './midlewares/renderNav.js';
import { logoutUser } from './views/logoutView.js';

//import * as api from './api/user.js';


page(decorateContext);
page(authMiddleware);
page(renderNav);
page('/', homeView);
page('/login', loginView);
page('/register', registerView);
page('/details/:id', detailsView);
page('/edit/:id', editView);
page('/profile', profileView);
page('/create', createView);
page('/logout', logoutUser);

page.start();

//window.api = api;
