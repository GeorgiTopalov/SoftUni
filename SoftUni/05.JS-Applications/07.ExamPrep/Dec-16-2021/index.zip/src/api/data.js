import * as api from './api.js';

/* export const login = api.login;
export const register = api.register;
export const logout = api.logout; */

const endpoints = {
    all: '/data/theaters?sortBy=_createdOn%20desc&distinct=title',
    catalog: '/data/theaters',
    byId: '/data/theaters/',
    myItem: (userId) => `/data/theaters?where=_ownerId%3D%22${userId}%22&sortBy=_createdOn%20desc`
}

export async function getAll() {
    return api.get(endpoints.all);
}

export async function createTheater(data) {
    return api.post(endpoints.catalog, data)
}
export async function getById(id) {
    return api.get(endpoints.byId + id);
}
export async function editTheater(id, data) {
    return api.put(endpoints.byId + id, data);
}
export async function removeById(id) {
    return api.del(endpoints.byId + id);
}
export async function getMyPlays(userId) {
    return api.get(endpoints.myItem(userId));
}


/* export async function getMyItems(userId){
    
} */