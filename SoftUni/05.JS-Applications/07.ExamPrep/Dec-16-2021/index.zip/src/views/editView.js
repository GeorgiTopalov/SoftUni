import { html } from '../../node_modules/lit-html/lit-html.js'
import {editTheater, getById } from '../api/data.js';
import { createSubmitHandler } from '../util.js';


const editTemplate = (play, onSubmit) => html`
<section id="editPage">
    <form @submit=${onSubmit} class="theater-form">
        <h1>Edit Theater</h1>
        <div>
            <label for="title">Title:</label>
            <input id="title" name="title" type="text" placeholder="Theater name" value=${play.title}>
        </div>
        <div>
            <label for="date">Date:</label>
            <input id="date" name="date" type="text" placeholder="Month Day, Year" value=${play.date}>
        </div>
        <div>
            <label for="author">Author:</label>
            <input id="author" name="author" type="text" placeholder="Author" value=${play.author}>
        </div>
        <div>
            <label for="description">Theater Description:</label>
            <textarea id="description" name="description" placeholder="Description">${play.description}</textarea>
        </div>
        <div>
            <label for="imageUrl">Image url:</label>
            <input id="imageUrl" name="imageUrl" type="text" placeholder="Image Url" value=${play.imageUrl}>
        </div>
        <button class="btn" type="submit">Submit</button>
    </form>
</section>`;

export async function editView(ctx) {
    const id = ctx.params.id;
    const play = await getById(id);

    console.log(play);
    ctx.render(editTemplate(play, createSubmitHandler(ctx, onSubmit)));
}

async function onSubmit(ctx, data, event) {
    if (Object.values(data).some(f => f == '')) {
        alert('All fields required!');
        return;
    }


    await editTheater(ctx.params.id, data);

    event.target.reset();
    ctx.page.redirect(`/details/${ctx.params.id}`);
}