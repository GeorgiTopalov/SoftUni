import { html } from '../../node_modules/lit-html/lit-html.js'
import * as data from '../api/data.js';

const detailsTemplate = (play, showButtons) => html`
<section id="detailsPage">
    <div id="detailsBox">
        <div class="detailsInfo">
            <h1>Title: ${play.title}</h1>
            <div>
                <img src=${play.imageUrl} />
            </div>
        </div>

        <div class="details">
            <h3>Theater Description</h3>
            <p>${play.description}</p>
            <h4>Date: ${play.date}</h4>
            <h4>Author: ${play.author}</h4>

            <div class="buttons">
                ${showButtons}
            </div>
            <p class="likes">Likes: 0</p>
        </div>
    </div>
</section>`;

function showButtons(ctx, play, deletePlay) {
    if (ctx.user) {
        if (ctx.user._id == play._ownerId) {
            return html`
            <a @click=${deletePlay} class="btn-delete" href="javascript:void(0)">Delete</a>
            <a class="btn-edit" href="/edit/${play._id}">Edit</a>
            <a class="btn-like" href="#">Like</a>`;
        } else {
            return html`
            <a class="btn-like" href="#">Like</a>`;
        }
    } else {
        return html``;
    }
}


export async function detailsView(ctx) {
    const id = ctx.params.id;
    const play = await data.getById(id);
    if (ctx.user) {
        play.isOwner = ctx.user._id == play._ownerId;
    }
    ctx.render(detailsTemplate(play, showButtons(ctx, play, deletePlay)));

    async function deletePlay() {
        const result = confirm("Do you really want to delete this play?");

        if (result) {
            await data.removeById(id);
            ctx.page.redirect('/profile');
        }
    }
}